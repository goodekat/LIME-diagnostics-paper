
---------------------------------------------------
INFORMATION ON THE CODE AND DATA FILES
---------------------------------------------------

Below are descriptions of the code and data files sumitted with the manuscript "Visual Diagnostics of a Model Explainer -- Tools for the Assessment of LIME Explanations" by Katherine Goode and Heike Hofmann.

manuscript-code.r: Contains all of the code used to produce the results and visualizations in the manuscript.

data-bullet-train.csv: 

data-bullet-train.csv: 

data-bullet-train.csv: