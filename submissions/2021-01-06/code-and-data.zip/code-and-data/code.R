## ----setup, echo = FALSE, include = FALSE------------------------------------------------
## # Specify global options
## knitr::opts_chunk$set(
##   warning = FALSE,
##   message = FALSE,
##   echo = FALSE,
##   fig.keep = 'high',
##   fig.align = 'center',
##   dev = c("cairo_pdf", "cairo_ps"),
##   dev.args = list(fallback_resolution = 800),
##   dpi = 1200
## )
## 
## # Load packages
## library(bulletxtrctr) #remotes::install_github("heike/bulletxtrctr")
## library(Cairo)
## library(caret)
## library(cowplot)
## library(dplyr)
## library(forcats)
## library(ggforce)
## library(ggplot2)
## library(ggpcp) #remotes::install_github("yaweige/ggpcp")
## library(glmnet)
## library(gower)
## library(graphics)
## library(gretchenalbrecht) #remotes::install_github("dicook/gretchenalbrecht")
## library(latex2exp)
## library(lime) #remotes::install_github("goodekat/lime")
## library(limeaid) #remotes::install_github("goodekat/limeaid")
## library(magick)
## library(purrr)
## library(randomForest)
## library(stringr)
## library(tidyr)
## 
## # Specify the (base) font size (fs) and font (ff) for all plots
## fs = 7
## ff = "Helvetica"


## ----concept-data-explainer--------------------------------------------------------------
## 
## # Specify the gower exponents
## good_gower_power <- 0.00000000000000005
## bad_gower_power <- 1
## 
## # Specify a prediction of interest
## poi <-
##   data.frame(
##     poi = "Prediction \nof Interest",
##     feature = 0.1,
##     prediction = 0.05
##   )
## 
## # Simulate example data
## set.seed(20190624)
## concept_data <-
##   data.frame(poi = "Training Data",
##              feature = sort(c(runif(100, 0, 1), runif(250, 0, 7)))) %>%
##   mutate(prediction = sin(feature) + rnorm(350, 0, 0.25)) %>%
##   bind_rows(poi)
## 
## # Compute the good distances between the prediction of interest
## # and all other observations
## concept_data$weights_good <-
##   1 - (gower_dist(
##     x = poi %>% select(feature),
##     y = concept_data %>% select(feature)
##   )) ^ good_gower_power
## 
## # Compute the bad distances between the prediction of interest
## # and all other observations
## concept_data$weights_bad <-
##   1 - (gower_dist(
##     x = poi %>% select(feature),
##     y = concept_data %>% select(feature)
##   )) ^ bad_gower_power
## 
## # Fit the good and bad interpretable explainer models
## explainer_good <-
##   lm(prediction ~ feature, data = concept_data, weights = weights_good)
## explainer_bad <-
##   lm(prediction ~ feature, data = concept_data, weights = weights_bad)
## 
## # Create labels for the gower powers
## good_power_label <-
##   paste0("Faithful Local Explainer \n(exponent used to compute weights: ",
##          good_gower_power,
##          ")")
## bad_power_label <-
##   paste0("Unfaithful Local Explainer \n(exponent used to compute weights: ",
##          bad_gower_power,
##          ")")
## 
## # Join the coefficients from the explainer model into a dataframe
## coefs_data <-
##   data.frame(
##     case = c(good_power_label, bad_power_label),
##     b0 = c(coef(explainer_good)[1],
##            coef(explainer_bad)[1]),
##     b1 = c(coef(explainer_good)[2],
##            coef(explainer_bad)[2]),
##     feature = 6,
##     prediction = 1.6
##   ) %>%
##   mutate(text = paste0("Slope: ", round(b1, 3)))
## 
## # Prepare data for plotting
## concept_data_long <-
##   concept_data %>%
##   pivot_longer(names_to = "case",
##                values_to = "weight",
##                cols = weights_good:weights_bad) %>%
##   mutate(case = ifelse(case == "weights_good", good_power_label, bad_power_label))


## ----figure-01, out.width = '6.5in', fig.width = 7.95, fig.height = 2.75, warning = FALSE----
## 
## # Specify the figure size (for determining font size)
## f1_ow = 6.5
## f1_fw = 7.95
## f1_fs = fs * (f1_fw / f1_ow)
## 
## # Plot of good explainer model
## ggplot() +
##   facet_grid(. ~ case) +
##   geom_point(
##     data = concept_data_long,
##     mapping = aes(
##       x = feature,
##       y = prediction,
##       fill = poi,
##       color = poi,
##       shape = poi,
##       alpha = poi,
##       size = weight
##     )
##   ) +
##   geom_abline(
##     data = coefs_data,
##     mapping = aes(intercept = b0, slope = b1),
##     size = 1
##   ) +
##   scale_fill_manual(values = c("#FAAA72", "grey30")) +
##   scale_color_manual(values = c("grey30", "grey30")) +
##   scale_alpha_manual(values = c(0.75, 0.6)) +
##   scale_shape_manual(values = c(23, 21)) +
##   geom_text(
##     data = coefs_data,
##     mapping = aes(x = feature,
##                   y = prediction,
##                   label = text),
##     family = ff,
##     size = f1_fs / 2.85
##   ) +
##   labs(x = "Black-Box Model Feature",
##        y = "Black-Box Prediction",
##        size = "Weight",
##        fill = "",
##        color = "",
##        alpha = "",
##        shape = "") +
##   theme_linedraw(base_family = ff, base_size = f1_fs) +
##   theme(
##     panel.grid.major = element_blank(),
##     panel.grid.minor = element_blank(),
##     axis.text.x = element_blank(),
##     axis.ticks.x = element_blank(),
##     axis.text.y = element_blank(),
##     axis.ticks.y = element_blank(),
##     strip.placement = "outside",
##     strip.background = element_rect(color = "white", fill = "white"),
##     strip.text.x = element_text(size = f1_fs, color = "black"),
##     plot.title = element_text(size = f1_fs)
##   ) +
##   guides(
##     fill = guide_legend(order = 1, override.aes = list(size = 5)),
##     color = guide_legend(order = 1),
##     shape = guide_legend(order = 1),
##     alpha = guide_legend(order = 1),
##     size = guide_legend(
##       order = 2,
##       override.aes = list(color = "grey30", alpha = 0.6)
##     )
##   )
## 


## ----sine-data, echo = FALSE, include = FALSE--------------------------------------------
## 
## # Functions for rotating the data
## rot_x <- function(x, y, theta) (x * cos(theta)) - (y * sin(theta))
## rot_y <- function(x, y, theta) (x * sin(theta)) + (y * cos(theta))
## 
## # Generate the data
## theta = -0.9
## min = -10
## max = 10
## set.seed(20190913)
## sine_data <- data.frame(x1 = runif(600, min, max),
##                         x2 = sort(runif(600, min, max))) %>%
##   mutate(x1new = rot_x(x1, x2, theta),
##          x2new = rot_y(x1, x2, theta),
##          y = ifelse(x2new > 5 * sin(x1new), "blue", "red")) %>%
##   slice(sample(1:n())) %>%
##   mutate(x3 = rnorm(600),
##          case = 1:600) %>%
##   select(case, everything())
## 
## # Separate the data into training and testing parts
## set.seed(20191003)
## rs <- sample(1:600, 500, replace = FALSE)
## sine_data_train <- sine_data[rs,]
## sine_data_test <- sine_data[-rs,]
## 
## # Fit a random forest
## set.seed(20191003)
## rfsine <- randomForest(x = sine_data_train %>% select(x1, x2, x3),
##                        y = factor(sine_data_train$y))
## 
## # Obtain predictions on the training and testing data
## sine_data_train$rfpred <- predict(rfsine)
## sine_data_train <- cbind(sine_data_train, predict(rfsine, type = "prob"))
## sine_data_train <- sine_data_train %>%
##   rename(rfprob_blue = blue, rfprob_red = red)
## sine_data_test$rfpred <- predict(rfsine, sine_data_test %>% select(x1, x2, x3))
## sine_data_test <- cbind(sine_data_test,
##                         predict(rfsine, sine_data_test
##                                 %>% select(x1, x2, x3),
##                                 type = "prob"))
## sine_data_test <- sine_data_test %>%
##   rename(rfprob_blue = blue, rfprob_red = red)
## 
## # Save the training and testing data
## if(!file.exists("data/sine-data-train.rds")) saveRDS(sine_data_train, "data/sine-data-train.rds")
## if(!file.exists("data/sine-data-test.rds")) saveRDS(sine_data_test, "data/sine-data-test.rds")
## 
## # Extract the prediction of interest from the sine test data
## sine_poi <- sine_data_test %>% filter(y != rfpred, x1 > 0, x1 < 5, x2 > 5)
## 


## ----figure-02, out.width = '6.5in', fig.width = 8, fig.height = 3.1---------------------
## 
## # Specify the figure size (for determining font size)
## f2_ow = 6.5
## f2_fw = 8
## f2_fs = fs * (f2_fw / f2_ow)
## f2_ls = 0.5 * (f2_fw / f2_ow)
## 
## # Create points representing the rotated since curve
## sinefun_data <- data.frame(xnew = seq(min(sine_data$x1new),
##                                       max(sine_data$x1new),
##                                       by = 0.01)) %>%
##   mutate(ynew = 5 * sin(xnew)) %>%
##   mutate(x = rot_x(xnew, ynew, -theta),
##          y = rot_y(xnew, ynew, -theta)) %>%
##   filter(y >= -10, y <= 10)
## 
## # Specify colors for predictions
## sinecolor_red = "firebrick"
## sinecolor_blue = "steelblue"
## 
## # Plot the training data observed classes
## sine_plot_obs <- ggplot(sine_data_train, aes(x = x1, y = x2, color = y)) +
##   geom_point(alpha = 0.8) +
##   geom_path(data = sinefun_data, aes(x = x, y = y),
##             color = "black",
##             size = f2_ls) +
##   scale_colour_manual(values = c(sinecolor_blue, sinecolor_red)) +
##   theme_bw(base_family = ff, base_size = f2_fs) +
##   theme(aspect.ratio = 1,
##         plot.title = element_text(size = f2_fs)) +
##   labs(x = TeX("$x_1$"),
##        y = TeX("$x_2$"),
##        color = TeX("y"),
##        title = "Training Data")
## 
## # Plot the testing data rf predictions
## sine_plot_pred <- ggplot() +
##   geom_point(data = sine_poi %>%
##                mutate(shape = "Prediction \nof Interest"),
##              mapping = aes(x = x1,
##                            y = x2,
##                            shape = shape),
##              size = 5,
##              alpha = 0.8,
##              color = "black") +
##   geom_point(data = sine_data_test %>% filter(y != rfpred),
##              mapping = aes(x = x1, y = x2),
##              shape = 1,
##              size = 3,
##              color = "black") +
##   geom_point(data = sine_data_test,
##              mapping =  aes(x = x1,
##                             y = x2,
##                             color = rfprob_blue,
##                             fill = rfprob_blue),
##              shape = 21,
##              alpha = 0.8) +
##   geom_path(data = sinefun_data, aes(x = x, y = y),
##             color = "black",
##             size = f2_ls) +
##   scale_color_gradient2(low = sinecolor_red,
##                         mid = '#f7f7f7',
##                         high = sinecolor_blue,
##                         midpoint = 0.5) +
##   scale_fill_gradient2(low = sinecolor_red,
##                         mid = '#f7f7f7',
##                         high = sinecolor_blue,
##                         midpoint = 0.5) +
##   scale_shape_manual(values = 23) +
##   theme_bw(base_family = ff, base_size = f2_fs) +
##   theme(aspect.ratio = 1,
##         plot.title = element_text(size = f2_fs)) +
##   labs(x = TeX("$x_1$"),
##        y = TeX("$x_2$"),
##        color = "Random \nForest \nProbability \nfor 'blue'",
##        fill = "Random \nForest \nProbability \nfor 'blue'",
##        title = "Testing Data",
##        shape = "") +
##   guides(shape = guide_legend(order = 1))
## 
## # Join the plots
## plot_grid(sine_plot_obs, sine_plot_pred,
##           nrow = 1,
##           rel_widths = c(0.4825, 0.5175))
## 


## ----sine-lime---------------------------------------------------------------------------
## 
## # Apply LIME with various tuning parameters to the sine data
## if (!file.exists("data/sine-lime-explain.rds")) {
## 
##     # Apply lime with various input options
##     sine_lime_explain <- apply_lime(
##       train = sine_data_train %>% select(x1, x2, x3),
##       test = sine_data_test %>% select(x1, x2, x3),
##       model = rfsine,
##       label = "blue",
##       n_features = 2,
##       sim_method = c('quantile_bins', "kernel_density"),
##       nbins = 2:6,
##       feature_select = "auto",
##       dist_fun = "gower",
##       kernel_width = NULL,
##       gower_pow = 1,
##       return_perms = TRUE,
##       all_fs = TRUE,
##       seed = 20190914)
## 
##     saveRDS(sine_lime_explain, "data/sine-lime-explain.rds")
## 
##     } else {
## 
##     sine_lime_explain <- readRDS("data/sine-lime-explain.rds")
## 
##   }
## 


## ----sine-lime-default, warning = FALSE--------------------------------------------------
## 
## # Extract the explanations from the default lime application
## sine_lime_default <- sine_lime_explain$explain %>% filter(nbins == 4)
## 
## # Extract the explanations from the default lime application
## # for the prediction of interest only
## sine_poi_lime_default <- sine_lime_default %>%
##   filter(case == sine_poi %>% pull(case)) %>%
##   mutate(case = c("Prediction of Interest", "Prediction of Interest"))
## 
## # Obtain the simulated data associated with the poi
## sine_poi_perms <- sine_poi_lime_default %>%
##   slice(1) %>%
##   select(perms_raw, perms_pred_complex, perms_numerified, weights) %>%
##   mutate(perms_numerified =
##            map(perms_numerified,
##                .f = function(x) rename(x,
##                                        "x1num" = "x1",
##                                        "x2num" = "x2",
##                                        "x3num" = "x3"))) %>%
##   unnest(cols = c(perms_raw, perms_pred_complex, perms_numerified, weights)) %>%
##   select(-red) %>%
##   rename(rfpred = blue) %>%
##   mutate(case = factor(1:n())) %>%
##   select(case, everything())
## 


## ----sine-poi-explainer, warning = FALSE-------------------------------------------------
## 
## # Determine the lime explanation cutoffs
## sine_poi_bounds <- sine_poi_lime_default %>%
##   select(case, feature, feature_value, feature_desc) %>%
##   separate(feature_desc, c("other", "upper"), sep = " <= ") %>%
##   separate(other, c("lower", "feature2"), sep = " < ") %>%
##   mutate(upper = ifelse(is.na(upper), "Inf", upper)) %>%
##   select(-feature2) %>%
##   mutate_at(.vars = c("lower", "upper"), .funs = as.numeric)
## 
## # Extract the coefficients from the explainer
## sine_b0 <- sine_poi_lime_default$model_intercept[1]
## sine_b1 <- sine_poi_lime_default$feature_weight[2]
## sine_b2 <- sine_poi_lime_default$feature_weight[1]
## 
## # Extract the bounds of the bins
## x1_lower <- sine_poi_bounds %>% filter(feature == "x1") %>% pull(lower)
## x1_upper <- sine_poi_bounds %>% filter(feature == "x1") %>% pull(upper)
## x2_lower <- sine_poi_bounds %>% filter(feature == "x2") %>% pull(lower)
## x2_upper <- sine_poi_bounds %>% filter(feature == "x2") %>% pull(upper)
## 
## # Function for computing the predicted value via the explainer model
## sine_explainer <- function(z1, z2) sine_b0 + sine_b1 * z1 + sine_b2 * z2
## 


## ----figure-03, out.width = '6.5in', fig.width = 12, fig.height = 5, warning = FALSE-----
## 
## # Specify the figure size (for determining font size)
## f3_ow = 6.5
## f3_fw = 12
## f3_fs = fs * (f3_fw / f3_ow)
## f3_ls = 0.5 * (f3_fw / f3_ow)
## 
## # Create the lime R package explanation visualization for the sine data
## sine_poi_exp <-
##   sine_poi_lime_default %>%
##   plot_features() +
##   theme(text = element_text(family = ff, size = f3_fs),
##         strip.text = element_text(size = f3_fs, face = "plain"))
## 
## # Create the explanation scatterplot for the lime explanation for the sine data
## exp_scatter <-
##   plot_explain_scatter(
##     sine_poi_lime_default,
##     alpha = 0.4,
##     line_size = f3_ls
##   ) +
##   facet_grid(switch = "both") +
##   labs(
##     x = TeX("x_1"),
##     y = TeX("x_2"),
##     size = "Weight",
##     shape = "",
##     fill = "Random \nForest \nProbability \nfor 'blue'",
##     color = "Random \nForest \nProbability \nfor 'blue'",
##     linetype = "",
##     title = "Explanation Scatterplot"
##   ) +
##   theme_bw(base_family = ff, base_size = f3_fs) +
##   guides(shape = guide_legend(order = 1),
##          size = guide_legend(
##            nrow = 2,
##            byrow = T,
##            override.aes = list(alpha = 1)
##          )) +
##   theme(aspect.ratio = 1,
##         plot.title = element_text(size = f3_fs))
## 
## # Join the plots
## plot_grid(sine_poi_exp, exp_scatter)
## 
## # Save the figure to use in the GitHub repo readme
## # ggsave(
## #   filename = "figure-readme.png",
## #   plot = plot_grid(sine_poi_exp, exp_scatter),
## #   width = 12,
## #   height = 5
## # )
## 


## ----figure-04, out.width = '3.125in', fig.width = 4.5, fig.height = 4.5-----------------
## 
## # Specify the figure size (for determining font size)
## f4_ow = 3.125
## f4_fw = 4.5
## f4_fs = fs * (f4_fw / f4_ow)
## 
## # Create the example feature heatmap with the sine data
## plot_feature_heatmap(sine_lime_explain$explain,
##                      order_method = "PCA") +
##   theme_bw(base_family = ff, base_size = f4_fs) +
##   theme(
##     legend.position = "bottom",
##     axis.text.y = element_blank(),
##     axis.ticks.y = element_blank(),
##     strip.background = element_rect(color = "white", fill = "white")
##   ) +
##   labs(y = "Case")
## 


## ----figure-05, out.width = '3.25in', fig.width = 4.5, fig.height = 3.75, warning = FALSE----
## 
## # Specify the figure size (for determining font size)
## f5_ow = 3.25
## f5_fw = 4.5
## f5_fs = fs * (f5_fw / f5_ow)
## 
## # Create the metric plot
## plot_metrics(sine_lime_explain$explain, rank_legend = "discrete") +
##   theme_bw(base_family = ff, base_size = f5_fs) +
##   theme(
##     strip.background = element_rect(color = "white", fill = "white"),
##     strip.placement = "outside",
##     strip.text.y = element_text(size = f5_fs)
##   )
## 


## ----bullet-data-------------------------------------------------------------------------
## # Load the bullet matching training and testing data
## bullet_train <- readr::read_csv("data/bullet-train.csv.zip")
## bullet_test <- readr::read_csv("data/bullet-test.csv.zip")


## ----bullet-rf---------------------------------------------------------------------------
## 
## # Extract the features from the original random forest model (rtrees)
## bullet_features <- rownames(bulletxtrctr::rtrees$importance)
## bullet_rf_ntrees <- bulletxtrctr::rtrees$ntree
## bullet_rf_mtry <- bulletxtrctr::rtrees$mtry
## 
## # Train a new random forest that mimics the rtrees models
## # (or load if already trained)
## bullet_rf_file = "./data/bullet-rf.rds"
## if (!file.exists(bullet_rf_file)) {
##   set.seed(20200923) # the day that the updated data was found :)
##   bullet_rf <-
##     randomForest(
##       y = factor(bullet_train$samesource),
##       x = bullet_train %>% select(all_of(bullet_features)),
##       ntree = bullet_rf_ntrees,
##       mtry = bullet_rf_mtry
##     )
##   saveRDS(object = bullet_rf, file = bullet_rf_file)
## } else {
##   bullet_rf = readRDS(file = bullet_rf_file)
## }
## 
## # Add variables to both training and testing data with the random forest probability
## # that the signatures are a match from the model bullet_rf
## bullet_train$rfscore = predict(bullet_rf, bullet_train %>% select(all_of(bullet_features)), type = "prob")[,2]
## bullet_test$rfscore = predict(bullet_rf, bullet_test %>% select(all_of(bullet_features)), type = "prob")[,2]
## 
## # Compute OOB model metrics
## bullet_rf_oob_acc = round(sum(predict(bullet_rf) == bullet_train$samesource) / length(bullet_train$samesource), 2)
## bullet_rf_oob_fp = round(bullet_rf$confusion[,3][2], 2)
## bullet_rf_oob_fn = round(bullet_rf$confusion[,3][1], 4)
## 
## # Obtain model predictions and confusion matrix from test data
## bullet_test_pred = predict(bullet_rf, bullet_test %>% select(all_of(bullet_features)))
## bullet_test_confus = table(bullet_test_pred, bullet_test$samesource)
## 
## # Compute test data model metrics
## bullet_rf_test_acc = round(sum(bullet_test_pred == bullet_test$samesource) / length(bullet_test$samesource), 2)
## bullet_rf_test_fp = round(bullet_test_confus[2,1] / (bullet_test_confus[2,1] + bullet_test_confus[2,2]), 2)
## bullet_rf_test_fn = round(bullet_test_confus[1,2] / (bullet_test_confus[1,1] + bullet_test_confus[1,2]), 4)


## ----bullet-feature-importance-----------------------------------------------------------
## # Order the features based on feature importance
## bullet_features_ordered <-
##   data.frame(
##     feature = rownames(bullet_rf$importance),
##     MeanDecreaseGini = bullet_rf$importance
##   ) %>%
##   arrange(desc(MeanDecreaseGini)) %>%
##   mutate(
##     feature = fct_recode(feature,
##       "Cross Correlation\nFunction" = "ccf",
##       "Consecutively\nMatching Striae" = "cms",
##       "Matches" = "matches",
##       "Mismatches" = "mismatches",
##       "Non-Consecutively\nMatching Striae" = "non_cms",
##       "Rough\nCorrelation" = "rough_cor",
##       "Distance Standard\nDeviation" = "sd_D",
##       "Distance" = "D",
##       "Sum of Peaks" = "sum_peaks"
##     )
##   )
## 
## # Create an ordered version of the data
## bullet_features_ordered <-
##   bullet_features_ordered %>%
##   mutate(feature = factor(feature, levels = bullet_features_ordered$feature))
## 


## ----figure-06, out.width = '2.25in', fig.width = 6, fig.height = 3, warning = FALSE-----
## 
## # Convert the bullet figure to eps (if needed)
## if (!file.exists("figure-static/figure-06-1.eps")) {
##   unzip(zipfile = "figure-static/figure-06-1.png.zip", exdir = "figure-static")
##   bullets <- image_read("figure-static/figure-06-1.png")
##   image_write(bullets, path = "figure-static/figure-06-1.eps", format = "eps")
## }
## 
## # Load and print the plot
## knitr::include_graphics("figure-static/figure-06-1.eps")
## 


## ----figure-07, out.width = '3.125in', fig.width = 6, fig.height = 3.25, warning = FALSE----
## 
## # Specify the figure size (for determining font size)
## f7_ow = 3.125
## f7_fw = 6
## f7_fs = fs * (f7_fw / f7_ow)
## 
## # Load the signatures data
## signatures <- readr::read_csv("data/example-signatures.csv.zip")
## 
## # Create plot of the signatures
## signatures %>%
##   ggplot(aes(x = x/1000, y = y)) +
##   geom_line() +
##   facet_grid(land ~ .) +
##   ylim(c(-4,6)) +
##   theme_bw(base_family = ff, base_size = f7_fs) +
##   theme(strip.background = element_blank()) +
##   ylab("Surface Measurement \n(in microns)") +
##   xlab("Relative Location (in millimeters)")
## 


## ----figure-08, out.width = '6.5in', warning = FALSE-------------------------------------
## 
## # File names for parallel coordinate plot
## pcp_file_name_png = "figure-static/figure-08-1.png"
## pcp_file_name_eps = "figure-static/figure-08-1.eps"
## 
## # Create the parallel coordinate plot (if needed)
## if (!file.exists(pcp_file_name_png) | !file.exists(pcp_file_name_eps)) {
## 
##   # Specify the figure size (for determining font size)
##   f8_ow = 6.5
##   f8_fw = 7.5
##   f8_fs = 7 * (f8_fw / f8_ow)
##   f8_ls = 0.5 * (f8_fw / f8_ow)
## 
##   # Create the plot
##   bullet_pcp <-
##     bullet_train %>%
##     select(all_of(bullet_features), samesource, rfscore) %>%
##     bind_rows(bullet_test %>%
##                 select(all_of(bullet_features), samesource, rfscore),
##               .id = "set") %>%
##     mutate(
##       set = fct_recode(set,
##                        "Training Set" = "1",
##                        "Testing Set" = "2"),
##       samesource = fct_recode(
##         factor(samesource),
##         "Match" = "TRUE",
##         "Non-Match" = "FALSE"
##       )
##     ) %>%
##     rename(
##       "Cross Correlation\nFunction" = "ccf",
##       "Consecutively\nMatching Striae" = "cms",
##       "Matches" = "matches",
##       "Mismatches" = "mismatches",
##       "Non-Consecutively\nMatching Striae" = "non_cms",
##       "Rough\nCorrelation" = "rough_cor",
##       "Distance Standard\nDeviation" = "sd_D",
##       "Distance" = "D",
##       "Sum of Peaks" = "sum_peaks"
##     ) %>%
##     arrange(rfscore) %>%
##     ggplot(aes(color = rfscore)) +
##     geom_pcp(
##       mapping = aes(vars = vars(bullet_features_ordered$feature)),
##       alpha = 0.2,
##       size = f8_ls
##     ) +
##     facet_grid(set ~ samesource) +
##     scale_color_gradient2(low = "grey50",
##                           high = "darkorange",
##                           midpoint = 0.5) +
##     theme_bw(base_family = ff, base_size = f8_fs) +
##     theme(
##       axis.text.x = element_text(angle = 45, vjust = 1, hjust = 1),
##       strip.placement = "outside",
##       strip.background = element_rect(color = "white",
##                                       fill = "white")
##     ) +
##     labs(x = "Features Ordered by Random Forest Variable Importance \n(highest to lowest from left to right)",
##          y = "Scaled Feature Values",
##          color = "Random \nForest \nProbability")
## 
##   # Save the plot
##   ggplot2::ggsave(
##     plot = bullet_pcp,
##     filename = pcp_file_name_png,
##     width = 7.5,
##     height = 3.5,
##     units = "in",
##     dpi = 400
##   )
## 
##   # Load the figure and then save as an EPS file
##   bullet_pcp <- image_read(pcp_file_name_png)
##   image_write(bullet_pcp, path = pcp_file_name_eps, format = "eps")
## 
## }
## 
## # Load and print the plot
## knitr::include_graphics(pcp_file_name_eps)
## 


## ----bullet-lime-------------------------------------------------------------------------
## 
## # Apply LIME to all but two cases without returning the permutations
## if (!file.exists("data/bullet-lime.rds") | !file.exists("data/bullet-explain.rds")){
## 
##   # Apply lime with various input options to the Hamby data
##   bullet_lime_explain_noperms <- apply_lime(
##     train = bullet_train %>%
##       select(all_of(bullet_features)),
##     test = bullet_test %>%
##       select(all_of(bullet_features)),
##     model = bullet_rf,
##     label = as.character(TRUE),
##     n_features = 3,
##     sim_method = c('quantile_bins', 'equal_bins',
##                    'kernel_density', 'normal_approx'),
##     nbins = 2:6,
##     feature_select = "auto",
##     dist_fun = "gower",
##     kernel_width = NULL,
##     gower_pow = c(0.5, 1, 10),
##     return_perms = FALSE,
##     all_fs = FALSE,
##     seed = 20190914)
## 
##   # Separate the lime and explain parts of the results
##   bullet_lime_noperms <- bullet_lime_explain_noperms$lime
##   bullet_explain_noperms <- bullet_lime_explain_noperms$explain
## 
##   # Save the output objects
##   saveRDS(object = bullet_lime_noperms, file = "data/bullet-lime.rds")
##   saveRDS(object = bullet_explain_noperms, file = "data/bullet-explain.rds")
## 
## } else {
## 
##   # Load the files
##   bullet_explain_noperms <- readRDS("data/bullet-explain.rds")
## 
## }
## 


## ----bullet-lime-perms-------------------------------------------------------------------
## 
## # Specify two cases of interest
## bullet_poi_match <-
##   bullet_test %>%
##   filter(land_id1 == "Hamby224-Set11-B1-L5",
##          land_id2 == "Hamby224-Set11-B2-L2") %>%
##   pull(case)
## bullet_poi_nonmatch <- bullet_test %>%
##   filter(land_id1 == "Hamby224-Set1-B2-L5",
##          land_id2 == "Hamby224-Set1-BUnk-L3") %>%
##   pull(case)
## 
## # Apply LIME to two cases with the permutations returned
## bullet_lime_explain_perms <- apply_lime(
##   train = bullet_train %>% select(all_of(bullet_features)),
##   test = bullet_test %>%
##     filter(case %in% bullet_poi_match) %>%
##     bind_rows(bullet_test %>%
##                 filter(case %in% bullet_poi_nonmatch)) %>%
##     select(all_of(bullet_features)),
##   model = bullet_rf,
##   label = as.character(TRUE),
##   n_features = 3,
##   sim_method = c(
##     'quantile_bins',
##     'equal_bins',
##     'kernel_density',
##     'normal_approx'
##   ),
##   nbins = 4,
##   feature_select = "auto",
##   dist_fun = "gower",
##   kernel_width = NULL,
##   gower_pow = 0.5,
##   return_perms = TRUE,
##   all_fs = FALSE,
##   seed = 20190914
## )
## 
## # Separate the lime and explain parts of the results
## bullet_lime_perms <- bullet_lime_explain_perms$lime
## bullet_explain_perms <- bullet_lime_explain_perms$explain %>%
##   mutate(case = ifelse(case == 1,
##                        bullet_poi_match,
##                        bullet_poi_nonmatch) %>% as.character())
## 


## ----bullet-lime-combined----------------------------------------------------------------
## 
## # Determine the application and case number of the poi
## # in the no_perms data
## poi_cases_no_perms <- bullet_explain_noperms %>%
##   filter(case %in% c(bullet_poi_match, bullet_poi_nonmatch),
##          nbins %in% c(4, NA),
##          gower_pow == 0.5) %>%
##   select(case, implementation) %>%
##   unique()
## 
## # Join the no perms data (with poi removed) with the
## # perms data (perms removed)
## bullet_explain <- bullet_explain_noperms %>%
##   anti_join(poi_cases_no_perms,
##             by = c("implementation", "case")) %>%
##   bind_rows(
##     bullet_explain_perms %>%
##       mutate(implementation = fct_recode(implementation,
##           "3" = "1",
##           "8" = "2",
##           "31" = "3",
##           "32" = "4"
##         )
##       ) %>%
##       select(
##         -perms_raw,-perms_numerified,
##         -perms_pred_simple,-perms_pred_complex,
##         -weights
##       )
##   )
## 


## ----figure-09, out.width = '6.5in', fig.width = 18, fig.height = 14---------------------
## 
## # Specify the figure size (for determining font size)
## f9_ow = 6.5
## f9_fw = 18
## f9_fs = fs * (f9_fw / f9_ow)
## 
## # Create a feature heatmap
## plot_feature_heatmap(
##   bullet_explain %>%
##     mutate(
##       label = as.factor(label),
##       feature = fct_recode(
##         feature,
##         "Rough Correlation" = "rough_cor",
##         "Consecutively Matching Striae" = "cms",
##         "Distance" = "D",
##         "Matches" = "matches",
##         "Mismatches" = "mismatches",
##         "Non-Consecutively Matching Striae" = "non_cms",
##         "Cross Correlation Function" = "ccf",
##         "Sum of Peaks" = "sum_peaks",
##         "Distance Standard Deviation" = "sd_D"
##       )
##     ),
##   facet_var = bullet_test %>%
##     mutate(samesource = fct_recode(
##       factor(samesource),
##       "Match" = "TRUE",
##       "Non-Match" = "FALSE"
##     )) %>%
##     pull(samesource),
##   order_method = "PCA"
## ) +
##   scale_fill_gretchenalbrecht(palette = "last_rays", discrete = TRUE) +
##   scale_color_gretchenalbrecht(palette = "last_rays",
##                                discrete = TRUE,
##                                reverse = TRUE) +
##   theme_bw(base_family = ff, base_size = f9_fs) +
##   theme(
##     axis.text.y = element_blank(),
##     axis.ticks.y = element_blank(),
##     strip.background = element_rect(color = "white", fill = "white"),
##     strip.text.y.right = element_text(angle = 0, size = f9_fs*0.7),
##     strip.text.x = element_text(size = f9_fs*0.7),
##     legend.position = "bottom",
##     axis.text.x = element_text(angle = 45, hjust = 1)
##   ) +
##   guides(fill = guide_legend(nrow = 3)) +
##   labs(y = "Case", color = "Complex Model Feature", fill = "Complex Model Feature")
## 


## ----figure-10, out.width = '6.5in', warning = FALSE, fig.width = 10, fig.height = 4.25----
## 
## # Specify the figure size (for determining font size)
## f10_ow = 6.5
## f10_fw = 10
## f10_fs = fs * (f10_fw / f10_ow)
## f10_ls = 0.5 * (f10_fw / f10_ow)
## 
## # Create a metric comparison plot
## plot_metrics(
##   bullet_explain %>%
##     mutate(label = as.factor(label)),
##   add_lines = TRUE,
##   line_alpha = 0.75,
##   line_size = f10_ls
## ) +
##   theme_bw(base_family = ff, base_size = f10_fs) +
##   theme(
##     strip.background = element_rect(color = "white", fill = "white"),
##     strip.placement = "outside",
##     strip.text.y = element_text(size = f10_fs)
##   )
## 


## ----figure-11, out.width = '6.25in', fig.width = 13, fig.height = 9, message = FALSE----
## 
## # Specify the figure size (for determining font size)
## f11_ow = 6.25
## f11_fw = 13
## f11_fs = fs * (f11_fw / f11_ow)
## f11_ls = 0.5 * (f11_fw / f11_ow)
## 
## # Adjust names of the cases
## bullet_explain_perms_clean <- bullet_explain_perms %>%
##   mutate(case = ifelse(case == bullet_poi_nonmatch, "NM", "M"))
## 
## # Save the cleaned explanations to use with the supporting information
## if(!file.exists("data/bullet-explain-perms-clean.rds")) {
##  saveRDS(bullet_explain_perms_clean, "data/bullet-explain-perms-clean.rds")
## }
## 
## # Create a theme for the lime explanation visualizations
## bullet_explain_plot_theme <-
##   list(
##     scale_fill_manual(values = c("darkorange", "grey50")),
##     theme(
##       text = element_text(family = ff, size = f11_fs),
##       strip.text.x = element_text(face = "plain", size = f11_fs)
##     )
##   )
## 
## # Create the lime explanation visualizations
## pfNM_3qb <- plot_features(bullet_explain_perms_clean[4:6,]) + bullet_explain_plot_theme
## pfNM_3eb <- plot_features(bullet_explain_perms_clean[10:12,]) + bullet_explain_plot_theme
## 
## # Create theme for explanation scatterplots
## bullet_eoi_plot_theme <-
##   list(
##     scale_color_gradient2(
##       low = "grey50",
##       high = "darkorange",
##       midpoint = 0.5,
##       limits = c(0, 1)
##     ),
##     scale_fill_gradient2(
##       low = "grey50",
##       high = "darkorange",
##       midpoint = 0.5,
##       limits = c(0, 1)
##     ),
##     theme_bw(base_family = ff, base_size = f11_fs),
##     theme(
##       aspect.ratio = 1,
##       plot.title = element_text(size = f11_fs),
##       strip.text.x = element_text(size = f11_fs),
##       strip.text.y = element_text(size = f11_fs),
##       strip.placement = "outside",
##       strip.background = element_rect(color = "white", fill = "white")
##     ),
##     guides(size = guide_legend(nrow = 2, byrow = T),
##            linetype = guide_legend(override.aes = list(color = c("grey50", "darkorange"))))
##   )
## 
## # Create the explanation scatterplots
## eoiNM_3qb <-
##   plot_explain_scatter(
##     bullet_explain_perms_clean[4:6, ],
##     alpha = 0.9,
##     weights = TRUE,
##     line_size = f11_ls
##   ) +
##   bullet_eoi_plot_theme +
##   guides(linetype = guide_legend(override.aes = list(color = c("darkorange"))))
## eoiNM_3eb <-
##   plot_explain_scatter(
##     bullet_explain_perms_clean[10:12,],
##     alpha = 0.9,
##     weights = TRUE,
##     line_size = f11_ls
##   ) +
##   bullet_eoi_plot_theme
## 
## # Join the plots
## plot_grid(
##   pfNM_3qb,
##   pfNM_3eb,
##   eoiNM_3qb,
##   eoiNM_3eb,
##   nrow = 2,
##   rel_heights = c(0.4, 0.6)
## )
## 


## ----figure-B1, out.width = '3.125in', fig.width = 5, fig.height = 4, warning = FALSE----
## 
## # Specify the figure size (for determining font size and line size)
## fb1_ow = 3.125
## fb1_fw = 5
## fb1_fs = fs * (fb1_fw / fb1_ow)
## fb1_ls = 0.5 * (fb1_fw / fb1_ow)
## 
## # Calculate the residuals from the explainer model
## y <- sine_poi_perms$rfpred
## sine_poi_explainer <-
##   function(x1, x2)
##     sine_b0 + (sine_b1 * x1) + (sine_b2 * x2)
## sine_poi_perms <- sine_poi_perms %>%
##   mutate(exppred = sine_poi_explainer(x1num, x2num)) %>%
##   mutate(resid = exppred - rfpred)
## 
## # Create the residual plot
## ggplot(sine_poi_perms, aes(x = exppred, y = resid)) +
##   geom_hline(yintercept = 0, size = fb1_ls) +
##   geom_jitter(alpha = 0.5, width = 0.02) +
##   theme_bw(base_family = ff, base_size = fb1_fs) +
##   theme(plot.title = element_text(size = fb1_fs)) +
##   labs(x = "Explainer Model Predictions",
##        y = "Explainer Model Residuals",
##        title = "Explainer Model Residual Plot")
## 

